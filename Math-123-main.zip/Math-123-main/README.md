<p align="center">
<kbd>
<img width="150px" src="/public/cygg-logo-invert.png">
</kbd>
</p>

🎮 CybriaGG is an unblocked site for users to access & play Roblox freely on Now.GG

> [!WARNING]
> Do not deploy this to Netlify, Github Pages, Cloudflare Pages or any Static web hosting services, they don't support Node.js
> It's best to use apps like Codesandbox, Replit, Render or others.

# Deploy

### These are the only apps I know that can successfully deploy CybriaGG

<a href="https://render.com/deploy?repo=https://github.com/CybriaTech/CybriaGG"><img height="30px" src="https://img.shields.io/badge/render-4f65f1.svg?style=for-the-badge&logo=render&logoColor=46e3b7"><img></a>

[![Run on Replit](https://binbashbanana.github.io/deploy-buttons/buttons/remade/replit.svg)](https://replit.com/github/CybriaTech/CybriaGG)

[![Deploy to Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2FCybriaTech%2FCybriaGG)

## Active Links

https://cygg.onrender.com/ - Official Link, May Shut Down At Times

https://cygg.cybriatech.dev/ - Official CybriaTech Domain (Expansion)

https://cybriagg.uk - Official Link

https://cygg.mooo.com - First FREEDNS

https://cygg.deleesportsmedicine.com - Second FreeDNS
